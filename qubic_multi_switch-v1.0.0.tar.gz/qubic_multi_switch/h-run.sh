#!/bin/bash

source /etc/profile

[ -t 1 ] && . colors

update_wallet_conf() {
    sed -i 's/"coin":"QUBIC"/"coin":"ANYCOIN"/' /hive-config/wallet.conf
}

revert_wallet_conf() {
    sed -i 's/"coin":"ANYCOIN"/"coin":"QUBIC"/' /hive-config/wallet.conf
}

source qubic_multi_switch.conf
source h-manifest.conf
source "$CUSTOM_CONFIG_FILENAME"

[[ -z $CUSTOM_LOG_BASENAME ]] && { echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}"; exit 1; }
[[ -z $CUSTOM_CONFIG_FILENAME ]] && { echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}"; exit 1; }
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && { echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}"; exit 1; }

CUSTOM_LOG_BASEDIR=$(dirname "${CUSTOM_LOG_BASENAME}")
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p "$CUSTOM_LOG_BASEDIR"

EPOCH_CHALLENGE_URL="http://qubic1.hk.apool.io:8001/api/qubic/mode"

start_command() {
    local line=$1
    local command="${line:$(($(expr index "$line" " ")))}"
    if [[ "$command" =~ ^nohup ]]; then
        $command 2>&1 | tee -a "${CUSTOM_LOG_BASENAME}.log" &
    else
        $command
    fi
    echo "$command"
    sleep 1
}

start_A=false
start_B=false
act_A=false
act_B=false

echo "start INIT"
echo "$EXTRA" | while IFS= read -r line; do
    if [[ "$line" =~ ^-INIT_ ]]; then
        start_command "$line"
    fi
done
echo "end INIT"

while true; do
    response=$(curl -s "$EPOCH_CHALLENGE_URL" | grep -o '"mode":[0-9]')
    if [[ $response == '"mode":1' ]]; then
        start_A=false
        start_B=true
    else
        start_A=true
        start_B=false
    fi

    if [[ "$start_A" = true && "$act_A" = false ]]; then
        act_A=true
        act_B=false
        echo "start A"
        echo "$EXTRA" | while IFS= read -r line; do
            if [[ "$line" =~ ^-A_ ]]; then
                start_command "$line"
            fi
        done
    elif [[ "$start_B" = true && "$act_B" = false ]]; then
        act_A=false
        act_B=true
        echo "start B"
        echo "$EXTRA" | while IFS= read -r line; do
            if [[ "$line" =~ ^-B_ ]]; then
                start_command "$line"
            fi
        done
    fi
    sleep 3
done
